import openpyxl as xl
#需要使用pip安装命令行具体做法是win键+r之后输入cmd后回车，在里面使用命令语句：pip install openpyxl\
#import ** as *方便以后引用，但是也要注意不能与这个项目下其他库的名称重合从而引起歧义
from openpyxl.chart import BarChart, Reference 
#从库中引用类

# def process_workbook(filename):
# 补充知识：缩排快捷键（在vs和pycharm里面都使用整体选中+tab缩进一格，整体选中后+shift+tab整体反缩进一格）
# 注意缩进，在您想封装该函数的时候要把下方统一选中按下tab之后，修改文件夹名字
    
wb=xl.load_workbook("test.xlsx")
# 注意原视频中老师使用的目录是该文件夹下面的
# 如果最终也无法找到该excel文件可以以下语句使用自动分配定向地址
# wb=xl.load_workbook(r"地址\test.xlsx")
# 注意，如果您使用的是linux系统，其内部的文件加的分类符号不是"\"而是"/"请注意区分
# 无论是使用wps还是windows office都是可以的但是注意excel文件的后缀必须是xlsx
# 如果希望复用该函数到不同的地方可以使用wb=xl.load_workbook
sheet=wb['Sheet1']
#把加载的xlsx文档的第一个表单命名给sheet方便引用
#请注意这里的大小写敏感必须是Sheet1

# cell=sheet['A1']
# cell=sheet.cell(1,1)
# 以上两个语句的意思是相同的都是把一个（1，1）单元格给了cell这个元素
# print(cell.value)  
# print(sheet.max_row)
#上面语句可以作为测试看是否成功引用了这个xlsx表格，正确输出结果是：number（第一列第一行） 12

for row in range(2,sheet.max_row+1):#注意这里的范围是sheet.max_row+1否则将输出不全，因为是小于该值，这个右边范围值在结果中是不输出的
# print(row) 方便测试使用
    cell=sheet.cell(row,4) 
    #将第四列每个循环一个值的横排都把该单元格元素给cell这个变量
    corrected_price=cell.value*0.9
    corrected_price_cell=sheet.cell(row,4)
    corrected_price_cell.value=corrected_price
    # 这三个变量的赋值精简为两个也可，但是命名三个变量的优点在于可以清晰地直接修改需要更正的价格的计算式子
    print("%.1f" % cell.value)
    #注意由于计算机对于浮点运算的定义如果不加以控制对于小数点位数的确定会出现小数点位数不统一以及小数点位数过多的情况，这里使用格式进行限制

values=Reference(sheet,
            min_row=2,
            max_row=sheet.max_row,
            min_col=4,
            max_col=4)
#Refercence（注意大小写）,确定了引用参数的范围。行数是从非字符的第二行开始到最后一行数字，列数是第四列

chart= BarChart()
chart.add_data(values)
sheet.add_chart(chart,'e2')
#BarChart提供了非常强大的画图功能，可以修改图例，颜色坐标轴等，您可以通过BarChart的说明手册进行进一步学习
#这个命令最基本的使用方法就是先将需要画图的范围值给指定画图的命令chart之后用add_chart(图表,'元格')将图标放到e2这个单元格子内部


wb.save("test4.xlsx")
# 为了不影响以前的xlsx表格一般我们再重新找个文件地址进行保存，同样的如果你不想保存到该同样的目录文件下你可以使用这个命令
#wb.save(r"目录/test2.xlsx")
#注意这里的后缀名一定要加上，这样才能保存为指定格式的excel文件，否则需要自行选取打开方式，十分麻烦
#通过加def之后改filename可以封装这个函数只需要找到文件夹名字就可以进行统一快速处理了
#wb.save(filename)
#之前我们就已经学习过如何找到目录中的所有文件，这样我们就可以在一个目录中找到每个文件进而快速处理大批量excel文件
